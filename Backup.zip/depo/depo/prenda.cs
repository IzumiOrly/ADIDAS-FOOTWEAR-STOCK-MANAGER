﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace depo
{
    class prenda : item
    {
        public string casillero { get; }
        prenda(string nombre, string codigo, string categoria, string genero, string casillero) : base (nombre, codigo, categoria, genero)
        {
            this.casillero = casillero;
        }
    }
}
