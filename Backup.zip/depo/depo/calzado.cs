﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace depo
{
    class calzado : item
    {
        public string estante {  get; }
        public string fila {  get; }

        public calzado(string nombre, string codigo, string categoria, string genero,
                  string estante, string fila)
       : base(nombre, codigo, categoria, genero) 
        {
            this.estante = estante;
            this.fila = fila;
        }
    }
}
