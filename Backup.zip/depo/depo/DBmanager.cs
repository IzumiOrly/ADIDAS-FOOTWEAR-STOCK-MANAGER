﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace depo
{
    class DBmanager
    {

        public List<calzado> listaDeCalzados = new List<calzado>();


        public void fromCalzadosDBtoList()
        {
            listaDeCalzados.Clear();

            string connectionString = "Server=localhost\\SQLEXPRESS;Database=DEPOADIDAS;Integrated Security=True;TrustServerCertificate=True;";
            string query = "SELECT codigo, nombre, categoria, genero, estante, fila FROM calzados";
                using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string codigo = reader["codigo"].ToString();
                            string nombre = reader["nombre"].ToString();
                            string categoria = reader["categoria"].ToString();
                            string genero = reader["genero"].ToString();
                            string estante = reader["estante"].ToString();
                            string fila = reader["fila"].ToString();
                            if (!listaDeCalzados.Any(c => c.codigo == codigo))
                            {
                                calzado c = new calzado(nombre, codigo, categoria, genero, estante, fila);
                                listaDeCalzados.Add(c);
                            }
                        }
                    }

                }

            }
        }

        public List<calzado> GetCalzados()
        {
            return listaDeCalzados;
        }

    }


}

