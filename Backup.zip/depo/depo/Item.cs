﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace depo
{
    class item
    {
        public string nombre { get; }
        public string codigo { get; }
        public string categoria { get; }
        public string genero { get; }

        public item(string nombre, string codigo, string categoria, string genero)
        {
            this.nombre = nombre;
            this.codigo = codigo;
            this.categoria = categoria;
            this.genero = genero;
        }
    }
}
